#!/usr/bin/env python3
"""
Enhanced Demo: Shows pattern emergence and automatic skill generation
"""

import sys
sys.path.insert(0, '/home/claude/emergent-orchestrator-skill')
from orchestrator import AlwaysOnOrchestrator


def run_emergence_demo():
    """Demonstrate emergent pattern detection and skill generation."""
    print("="*80)
    print("🌟 EMERGENT SKILL GENERATION DEMO")
    print("="*80)
    print("\nThis demo shows how the orchestrator detects patterns and")
    print("automatically generates new skills when patterns stabilize.")
    print("="*80)
    
    orchestrator = AlwaysOnOrchestrator()
    
    # Tasks that will create a repeating pattern
    tasks = [
        # Pattern 1: Transfer Learning + Meta Learning (3 times = emergence!)
        {
            'task': "Learn Rust by comparing it to Python",
            'skills': ["transfer_learning", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.89, 
                       'dimensions': {'G': 0.88, 'C': 0.87, 'S': 0.90, 'A': 0.91, 'H': 0.89, 'V': 0.88}}
        },
        {
            'task': "Understand neural networks via biological neuron analogy",
            'skills': ["transfer_learning", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.92,
                       'dimensions': {'G': 0.91, 'C': 0.90, 'S': 0.93, 'A': 0.94, 'H': 0.92, 'V': 0.90}}
        },
        {
            'task': "Explain quantum entanglement using classical correlation",
            'skills': ["transfer_learning", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.94,
                       'dimensions': {'G': 0.93, 'C': 0.92, 'S': 0.95, 'A': 0.96, 'H': 0.94, 'V': 0.92}}
        },
        
        # Pattern 2: Autonomous Development + Self Improvement (3 times)
        {
            'task': "Build a web scraper and optimize it",
            'skills': ["autonomous_development", "self_improvement"],
            'outcome': {'success': True, 'q_score': 0.88,
                       'dimensions': {'G': 0.87, 'C': 0.86, 'S': 0.89, 'A': 0.90, 'H': 0.88, 'V': 0.87}}
        },
        {
            'task': "Create a REST API and refine its performance",
            'skills': ["autonomous_development", "self_improvement"],
            'outcome': {'success': True, 'q_score': 0.91,
                       'dimensions': {'G': 0.90, 'C': 0.89, 'S': 0.92, 'A': 0.93, 'H': 0.91, 'V': 0.89}}
        },
        {
            'task': "Develop a CLI tool and make it production-ready",
            'skills': ["autonomous_development", "self_improvement"],
            'outcome': {'success': True, 'q_score': 0.93,
                       'dimensions': {'G': 0.92, 'C': 0.91, 'S': 0.94, 'A': 0.95, 'H': 0.93, 'V': 0.91}}
        },
        
        # Pattern 3: Universal Problem Solving + Meta Learning (3 times)
        {
            'task': "Optimize this algorithm and learn the general pattern",
            'skills': ["universal_problem_solving", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.87,
                       'dimensions': {'G': 0.86, 'C': 0.85, 'S': 0.88, 'A': 0.89, 'H': 0.87, 'V': 0.86}}
        },
        {
            'task': "Solve this constraint satisfaction problem efficiently",
            'skills': ["universal_problem_solving", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.90,
                       'dimensions': {'G': 0.89, 'C': 0.88, 'S': 0.91, 'A': 0.92, 'H': 0.90, 'V': 0.88}}
        },
        {
            'task': "Debug this complex system and extract debugging principles",
            'skills': ["universal_problem_solving", "meta_learning"],
            'outcome': {'success': True, 'q_score': 0.92,
                       'dimensions': {'G': 0.91, 'C': 0.90, 'S': 0.93, 'A': 0.94, 'H': 0.92, 'V': 0.90}}
        },
    ]
    
    print("\n📊 Processing task sequence...")
    print("="*80)
    
    emergent_count = 0
    
    for i, task_info in enumerate(tasks, 1):
        task = task_info['task']
        skills = task_info['skills']
        outcome = task_info['outcome']
        
        print(f"\n🎯 Task {i}: {task}")
        print(f"   Skills used: {', '.join(skills)}")
        
        # Record outcome (this triggers pattern detection)
        orchestrator.record_outcome(task, skills, outcome)
        
        print(f"   ✅ Q-score: {outcome['q_score']:.3f}")
        
        # Check if we just generated a new skill
        current_emergent = orchestrator.pattern_detector.get_pattern_stats()['emergent_skills_generated']
        if current_emergent > emergent_count:
            emergent_count = current_emergent
            print(f"\n   🎉 NEW EMERGENT SKILL GENERATED! (Total: {emergent_count})")
    
    # Final statistics
    print("\n" + "="*80)
    print("📈 FINAL STATISTICS")
    print("="*80)
    
    stats = orchestrator.get_stats()
    
    print(f"\n📊 Pattern Analysis:")
    print(f"   Total tasks processed: {stats['pattern_stats']['total_uses']}")
    print(f"   Unique patterns detected: {stats['pattern_stats']['unique_patterns']}")
    print(f"   🌟 Emergent skills generated: {stats['pattern_stats']['emergent_skills_generated']}")
    
    print(f"\n🔝 Most Common Patterns:")
    for pattern, freq in stats['pattern_stats']['top_patterns']:
        emoji = "✨" if freq >= 3 else "📊"
        status = "(EMERGENT SKILL CREATED)" if freq >= 3 else f"({freq}/3 to emergence)"
        print(f"   {emoji} {pattern}: {freq} uses {status}")
    
    print("\n" + "="*80)
    print("💾 Generated Skills")
    print("="*80)
    
    # List generated skills
    import os
    from pathlib import Path
    
    generated_dir = Path("/home/claude/emergent-orchestrator-skill/generated")
    if generated_dir.exists():
        skill_files = list(generated_dir.glob("SKILL_*.md"))
        if skill_files:
            print(f"\n✅ {len(skill_files)} emergent skills created:")
            for skill_file in sorted(skill_files):
                print(f"   📄 {skill_file.name}")
                
                # Show first few lines
                with open(skill_file, 'r') as f:
                    lines = f.readlines()[:5]
                    for line in lines:
                        if line.strip():
                            print(f"      {line.rstrip()}")
                print()
        else:
            print("\n   (No skills generated yet)")
    
    print("="*80)
    print("✅ EMERGENCE DEMO COMPLETE")
    print("="*80)
    print("\n🎓 Key Insights:")
    print("   - Patterns detected after 3+ repeated uses")
    print("   - New skills automatically generated with boosted Q-scores")
    print("   - System learns optimal skill combinations from experience")
    print("   - Emergent capabilities exceed individual parent skills")
    print("\n🚀 The orchestrator is now self-evolving!")


if __name__ == "__main__":
    run_emergence_demo()
